#Mon Nov 27 21:14:41 GMT 2023
dev/spi/ibm/com.ibm.websphere.appserver.spi.logging_1.1.84.jar=92c6c7c8fc0e6654e0fb7f6a0ae9c8fd
lib/platform/defaultLogging-1.0.mf=5dca00ad3a1c72fd06670dc28717f34f
dev/spi/ibm/javadoc/com.ibm.websphere.appserver.spi.logging_1.1-javadoc.zip=58f5c5d8127e2db967e8d51fdd46b0b7
lib/com.ibm.ws.collector.manager_1.0.84.jar=a2a7d75a3f8cdd1254b8ee3f7f63abab
lib/com.ibm.ws.logging.osgi_1.0.84.jar=6873551666877441b9d385f51338fe98
lib/com.ibm.ws.logging_1.0.84.jar=53760683a2a42f42c44ac00324687c6e
